package com.ahmed.downloader

import android.Manifest
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {

    private var sharedLink: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sharedLink = extractLink(intent)
        setContent { DownloaderScreen(sharedLink) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        sharedLink = extractLink(intent)
        setContent { DownloaderScreen(sharedLink) }
    }

    private fun extractLink(intent: Intent?): String {
        if (intent == null) return ""
        if (intent.action == Intent.ACTION_SEND) {
            val text = intent.getStringExtra(Intent.EXTRA_TEXT) ?: ""
            return findUrl(text) ?: text
        }
        if (intent.action == Intent.ACTION_VIEW) {
            return intent.dataString ?: ""
        }
        return ""
    }

    private fun findUrl(text: String): String? {
        val match = Regex("""https?://[^\s]+""").find(text)
        return match?.value?.trimEnd('.', ',', ')')
    }
}

fun detectPlatform(url: String): String {
    val u = url.lowercase()
    return when {
        "instagram.com" in u -> "إنستجرام"
        "tiktok.com" in u -> "تيك توك"
        "facebook.com" in u || "fb.watch" in u -> "فيسبوك"
        "youtube.com" in u || "youtu.be" in u -> "يوتيوب"
        "x.com" in u || "twitter.com" in u -> "إكس / تويتر"
        "snapchat.com" in u -> "سناب شات"
        "pinterest." in u -> "بينترست"
        "reddit.com" in u -> "ريديت"
        else -> "رابط عام"
    }
}

fun loadHistory(context: Context): List<String> {
    val prefs = context.getSharedPreferences("downloader_history", Context.MODE_PRIVATE)
    return prefs.getStringSet("files", emptySet())?.toList()?.sortedDescending() ?: emptyList()
}

fun saveHistory(context: Context, filename: String) {
    val prefs = context.getSharedPreferences("downloader_history", Context.MODE_PRIVATE)
    val set = prefs.getStringSet("files", emptySet())?.toMutableSet() ?: mutableSetOf()
    set.add(filename)
    prefs.edit().putStringSet("files", set.takeLast(30).toSet()).apply()
}

@Composable
fun DownloaderScreen(initialLink: String) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val scroll = rememberScrollState()

    var link by remember { mutableStateOf(initialLink) }
    var quality by remember { mutableStateOf("720") }
    var audioOnly by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var results by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var history by remember { mutableStateOf(loadHistory(context)) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    fun downloadFile(item: MediaItem) {
        askNotificationPermission()
        try {
            val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val request = DownloadManager.Request(Uri.parse(item.url))
                .setTitle(item.filename)
                .setDescription("تحميل من السوشيال")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedNetworkTypes(
                    DownloadManager.Request.NETWORK_WIFI or DownloadManager.Request.NETWORK_MOBILE
                )
                .setDestinationInExternalPublicDir(
                    Environment.DIRECTORY_DOWNLOADS,
                    "SocialDownloader/${item.filename}"
                )
            dm.enqueue(request)
            saveHistory(context, item.filename)
            history = loadHistory(context)
            status = "بدأ التحميل: ${item.filename}\nهتلاقيه في مجلد Downloads ثم SocialDownloader"
            Toast.makeText(context, "بدأ التحميل", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            status = "مش قادر أبدأ التحميل: ${e.message}"
        }
    }

    fun startResolve() {
        val url = link.trim()
        if (url.isBlank()) {
            status = "الصق رابط الأول"
            return
        }
        if (!url.startsWith("http")) {
            status = "الرابط لازم يبدأ بـ https://"
            return
        }
        results = emptyList()
        isLoading = true
        status = "جاري جلب الملف من ${detectPlatform(url)}..."
        scope.launch {
            val items = withContext(Dispatchers.IO) {
                val fromCobalt = CobaltClient.resolve(url, quality, audioOnly)
                if (fromCobalt.isNotEmpty()) fromCobalt
                else DirectExtractor.extract(url)
            }
            isLoading = false
            if (items.isEmpty()) {
                status = "مقدرتش أجيب الملف من الرابط ده.\n" +
                    "تأكد إن البوست عام مش خاص، وجرّب رابط تاني، " +
                    "أو جرّب من تطبيق المنصة نفسه: مشاركة ثم نسخ الرابط."
            } else {
                results = items
                status = if (items.size == 1) {
                    "لقيت ملف واحد، دوس تحميل تحت."
                } else {
                    "لقيت ${items.size} ملفات (مثلا ألبوم صور أو سلايدشو)، حمّل اللي يعجبك."
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scroll)
            .padding(20.dp),
        verticalArrangement = Arrangement.Top
    ) {
        Text("حمّل من السوشيال", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text(
            "الصق رابط صورة أو ريلز أو فيديو، وحمّله على تليفونك.\n" +
                "يدعم: إنستجرام، تيك توك، فيسبوك، يوتيوب، إكس، سناب، بينترست، ريديت.",
            fontSize = 15.sp
        )
        Spacer(Modifier.height(16.dp))

        OutlinedTextField(
            value = link,
            onValueChange = { link = it },
            label = { Text("الصق الرابط هنا") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = false,
            minLines = 2
        )
        Spacer(Modifier.height(10.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                val text = clipboard.getText()?.text ?: ""
                if (text.isNotBlank()) {
                    link = Regex("""https?://[^\s]+""").find(text)?.value ?: text
                    status = "تم اللصق من الحافظة"
                } else {
                    status = "الحافظة فاضية، انسخ الرابط الأول"
                }
            }) { Text("لصق") }
            OutlinedButton(onClick = {
                link = ""
                results = emptyList()
                status = ""
            }) { Text("مسح") }
            OutlinedButton(onClick = {
                clipboard.setText(AnnotatedString(link))
                Toast.makeText(context, "تم النسخ", Toast.LENGTH_SHORT).show()
            }) { Text("نسخ الرابط") }
        }
        Spacer(Modifier.height(12.dp))

        Text("الجودة:", fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("720", "1080", "max").forEach { q ->
                OutlinedButton(onClick = { quality = q }) {
                    Text(if (q == "max") "الأعلى" else q + "p")
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { audioOnly = false }) { Text("فيديو / صورة") }
            OutlinedButton(onClick = { audioOnly = true }) { Text("صوت فقط MP3") }
        }
        if (audioOnly) {
            Text("وضع الصوت فقط: هيحمّل صوت الفيديو MP3", fontSize = 13.sp)
        }
        Spacer(Modifier.height(16.dp))

        Button(
            onClick = { startResolve() },
            modifier = Modifier.fillMaxWidth(),
            enabled = !isLoading
        ) { Text("تحميل", fontSize = 18.sp) }
        Spacer(Modifier.height(12.dp))

        if (isLoading) {
            CircularProgressIndicator()
            Spacer(Modifier.height(8.dp))
        }
        if (status.isNotBlank()) {
            Text(status, fontSize = 15.sp)
            Spacer(Modifier.height(12.dp))
        }

        results.forEach { item ->
            Text("${item.kind} - ${item.filename}", fontSize = 14.sp)
            Spacer(Modifier.height(6.dp))
            Button(
                onClick = { downloadFile(item) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("تحميل الملف ده") }
            Spacer(Modifier.height(12.dp))
        }

        if (history.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Text("آخر التحميلات:", fontWeight = FontWeight.Bold)
            history.take(10).forEach { name ->
                Text("- $name", fontSize = 13.sp)
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "مكان الحفظ: مجلد Downloads ثم SocialDownloader",
                fontSize = 13.sp
            )
        }

        Spacer(Modifier.height(16.dp))
        Text(
            "ملحوظة: حمّل بس المحتوى العام أو اللي ليك حق فيه، " +
                "ومتستخدمش التطبيق لإعادة نشر شغل حد تاني من غير إذنه. " +
                "البوستات الخاصة مش هتتحمّل من غير تسجيل دخول.",
            fontSize = 13.sp
        )
    }
}
