package com.ahmed.downloader

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

/**
 * Fallback when Cobalt does not answer: fetch the public post page and
 * look for the direct media file (og:video / og:image / .mp4 links).
 * Works best for public posts. Private posts need a login and will fail,
 * that is normal for every downloader app.
 */
object DirectExtractor {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private val directExtensions = listOf(".mp4", ".mov", ".webm", ".jpg", ".jpeg", ".png", ".webp")

    suspend fun extract(pageUrl: String): List<MediaItem> = withContext(Dispatchers.IO) {
        val lower = pageUrl.lowercase()
        // Direct media link: download it as-is.
        if (directExtensions.any { lower.substringBefore("?").endsWith(it) }) {
            val kind = if (lower.contains(".mp4") || lower.contains(".mov") || lower.contains(".webm")) "video" else "image"
            return@withContext listOf(
                MediaItem(pageUrl, CobaltClient.fileNameFromUrl(pageUrl, false), kind)
            )
        }

        return@withContext try {
            val request = Request.Builder()
                .url(pageUrl)
                .addHeader(
                    "User-Agent",
                    "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"
                )
                .addHeader("Accept", "text/html,application/xhtml+xml")
                .build()
            client.newCall(request).execute().use { response ->
                val html = response.body?.string() ?: return@withContext emptyList()
                val found = linkedSetOf<String>()
                // og:video / og:image meta tags
                val metaRegex = Regex(
                    """content=["'](https?://[^"']+\.(?:mp4|mov|webm|jpg|jpeg|png|webp)[^"']*)["']"""
                )
                metaRegex.findAll(html).forEach { found.add(it.groupValues[1].replace("&amp;", "&")) }
                // Any .mp4 link in the page
                val mp4Regex = Regex("""https?://[^\s"'<>\\]+\.mp4[^\s"'<>\\]*""")
                mp4Regex.findAll(html).take(5).forEach { found.add(it.value.replace("&amp;", "&")) }
                found.mapIndexed { index, url ->
                    val kind = if (url.contains(".mp4") || url.contains(".mov") || url.contains(".webm")) "video" else "image"
                    MediaItem(url, CobaltClient.fileNameFromUrl(url, false, index), kind)
                }
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
