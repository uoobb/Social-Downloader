package com.ahmed.downloader

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Cobalt is an open-source downloader API.
 * POST <instance>/  with {"url": "...", "videoQuality": "720"}
 * Response: {"status":"tunnel"|"redirect", "url":"...", "filename":"..."}
 * or {"status":"picker", "picker":[{"type":"video","url":"..."}]}
 * or {"status":"error", ...}
 *
 * The official api.cobalt.tools now needs a JWT / bot check, so the app
 * tries community instances first. The first one below was verified
 * working on 2026-11-22 for a public TikTok link.
 * If an instance stops working, the app just tries the next one.
 */
object CobaltClient {

    private val instances = listOf(
        "https://api.cobalt.liubquanti.click",
        "https://co.wuk.sh",
        "https://cobalt.stream.gdn",
        "https://cobaltapi.kittycat.boo",
        "https://api.cobalt.tools",
        "https://cobalt.squair.xyz",
        "https://co.cjs.nz"
    )

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun resolve(
        pageUrl: String,
        quality: String,
        audioOnly: Boolean
    ): List<MediaItem> = withContext(Dispatchers.IO) {
        for (instance in instances) {
            try {
                val items = tryInstance(instance, pageUrl, quality, audioOnly)
                if (items.isNotEmpty()) return@withContext items
            } catch (e: Exception) {
                // Try the next instance.
            }
        }
        emptyList()
    }

    private fun tryInstance(
        instance: String,
        pageUrl: String,
        quality: String,
        audioOnly: Boolean
    ): List<MediaItem> {
        val bodyJson = JSONObject().apply {
            put("url", pageUrl)
            put("videoQuality", quality)
            put("downloadMode", if (audioOnly) "audio" else "auto")
            put("filenameStyle", "basic")
            if (audioOnly) put("audioFormat", "mp3")
        }.toString()

        val request = Request.Builder()
            .url(instance.trimEnd('/') + "/")
            .addHeader("Accept", "application/json")
            .addHeader("Content-Type", "application/json")
            .post(bodyJson.toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            val text = response.body?.string() ?: return emptyList()
            if (!response.isSuccessful) return emptyList()
            val json = JSONObject(text)
            val status = json.optString("status")
            return when (status) {
                "redirect", "tunnel" -> {
                    val url = json.optString("url")
                    if (url.isBlank()) emptyList()
                    else {
                        val name = json.optString("filename").ifBlank {
                            fileNameFromUrl(url, audioOnly)
                        }
                        listOf(MediaItem(url, name, if (audioOnly) "audio" else "video"))
                    }
                }
                "picker" -> {
                    val picker = json.optJSONArray("picker") ?: return emptyList()
                    val out = mutableListOf<MediaItem>()
                    for (i in 0 until picker.length()) {
                        val item = picker.optJSONObject(i) ?: continue
                        val url = item.optString("url")
                        if (url.isBlank()) continue
                        val type = item.optString("type", "video")
                        out.add(MediaItem(url, fileNameFromUrl(url, false, i), type))
                    }
                    out
                }
                else -> emptyList()
            }
        }
    }

    fun fileNameFromUrl(url: String, audioOnly: Boolean, index: Int = 0): String {
        val clean = url.substringBefore("?").substringAfterLast("/")
        val base = if (clean.isBlank()) "download" else clean
        val withIndex = if (index > 0) "${index + 1}_$base" else base
        return if (audioOnly && !withIndex.endsWith(".mp3")) "$withIndex.mp3" else withIndex
    }
}

data class MediaItem(
    val url: String,
    val filename: String,
    val kind: String
)
